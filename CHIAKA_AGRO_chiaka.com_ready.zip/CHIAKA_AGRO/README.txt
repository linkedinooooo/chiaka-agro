CHIAKA AGRO WEBSITE
====================

Open index.html in a browser to test the website.

Included pages (11):
1. index.html — Home
2. herbicides.html
3. insecticides.html
4. crops.html
5. services.html
6. detail.html — shared item detail page
7. purchase.html — purchase form
8. request.html — service request form
9. search.html
10. admin.html — owner/demo management page
11. styles.css / app.js — shared design and functionality

IMPORTANT:
- Purchase/request submissions are stored in the browser's localStorage and appear in admin.html.
- This means the demo does NOT yet send a real notification to your phone/email or synchronize across devices.
- The real production version should use a secure backend/database plus email/SMS/WhatsApp/push notifications.
- The owner code CHINYAMMORRIS123 is implemented as requested for this prototype, but it is NOT secure authentication.
- Replace the sample products with your actual goods, prices, photos, descriptions and phone numbers.
- Images currently use public Unsplash image URLs. For a production site, upload your own product images.

NEXT PRODUCTION FEATURES RECOMMENDED:
- Secure admin login/password and password reset
- Cloud database for products, images and requests
- Real-time inbox
- Email/SMS/WhatsApp notifications
- Product stock and price management
- Mobile-friendly checkout/request flow
- HTTPS, validation, rate limiting and spam protection
