
const products = {
  herbicides:[
    {id:"herb-1",name:"Premium Herbicide",desc:"Broad-use weed control product.",img:"https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=900&q=80"},
    {id:"herb-2",name:"Crop-Safe Herbicide",desc:"Designed for effective weed management.",img:"https://images.unsplash.com/photo-1530836369250-ef72a0c4a0a7?auto=format&fit=crop&w=900&q=80"},
    {id:"herb-3",name:"Field Guard Herbicide",desc:"For farms requiring dependable weed control.",img:"https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&w=900&q=80"}
  ],
  insecticides:[
    {id:"insect-1",name:"Farm Shield Insecticide",desc:"For managing common crop insect pests.",img:"https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=900&q=80"},
    {id:"insect-2",name:"Pest Control Plus",desc:"A crop protection option for pest management.",img:"https://images.unsplash.com/photo-1492496913980-501348b61469?auto=format&fit=crop&w=900&q=80"},
    {id:"insect-3",name:"Green Guard Pesticide",desc:"For responsible farm pest-control programmes.",img:"https://images.unsplash.com/photo-1523742819196-9e4f4f6f1e6b?auto=format&fit=crop&w=900&q=80"}
  ],
  crops:[
    {id:"crop-1",name:"Healthy Maize Seed",desc:"Quality crop input for your farming plans.",img:"https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=900&q=80"},
    {id:"crop-2",name:"Rice Seed",desc:"Selected seed option for rice production.",img:"https://images.unsplash.com/photo-1536631002873-3e8f2b1e2f9c?auto=format&fit=crop&w=900&q=80"},
    {id:"crop-3",name:"Vegetable Seeds",desc:"Seeds for productive vegetable gardens.",img:"https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=900&q=80"}
  ]
};

const services = [
  {id:"service-1",name:"Farm Advisory",desc:"Practical guidance for crop and farm-input decisions."},
  {id:"service-2",name:"Farm Input Supply",desc:"Request agricultural inputs for your farm needs."},
  {id:"service-3",name:"Bulk & Occasion Supply",desc:"Ask about larger orders and special supply arrangements."}
];

function allItems(){
  return [
    ...products.herbicides.map(x=>({...x,type:"herbicides"})),
    ...products.insecticides.map(x=>({...x,type:"insecticides"})),
    ...products.crops.map(x=>({...x,type:"crops"})),
    ...services.map(x=>({...x,type:"services"}))
  ];
}
function imgOrPlaceholder(item){
  return item.img || "https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=900&q=80";
}
function card(item){
  const action = item.type==="services"
    ? `<a class="btn request" href="request.html?item=${encodeURIComponent(item.name)}&type=service">Request</a>`
    : `<a class="btn purchase" href="purchase.html?item=${encodeURIComponent(item.name)}">Purchase</a>`;
  return `<article class="card">
    <a href="detail.html?id=${encodeURIComponent(item.id)}&type=${item.type}"><img src="${imgOrPlaceholder(item)}" alt="${item.name}"></a>
    <div class="card-body"><h3>${item.name}</h3><p>${item.desc}</p><div class="actions">
    <a class="btn back" href="detail.html?id=${encodeURIComponent(item.id)}&type=${item.type}">View details</a>${action}</div></div>
  </article>`;
}
function renderCategory(type){
  const el=document.getElementById("products");
  const arr=type==="services"?services:products[type];
  el.innerHTML=arr.map(x=>card({...x,type})).join("");
}
function getParam(k){return new URLSearchParams(location.search).get(k)}
function findItem(id,type){
  const arr=type==="services"?services:products[type]||[];
  return arr.find(x=>x.id===id);
}
function renderDetail(){
  const type=getParam("type"), id=getParam("id"), item=findItem(id,type);
  if(!item)return;
  document.title=`${item.name} | CHIAKA AGRO`;
  document.getElementById("detail").innerHTML=`<div><img src="${imgOrPlaceholder(item)}" alt="${item.name}"></div><div class="panel">
  <h1>${item.name}</h1><p>${item.desc}</p>
  <p>This product/service can be updated from the owner upload/settings area. Add price, pack size, usage information, stock status and other details there.</p>
  ${type==="services"?`<a class="btn request" href="request.html?item=${encodeURIComponent(item.name)}&type=service">Request</a>`:`<a class="btn purchase" href="purchase.html?item=${encodeURIComponent(item.name)}">Purchase</a>`}
  </div>`;
}
function submitRequest(form, isService=false){
  const item=form.item.value, name=form.name.value.trim(), phone=form.phone.value.trim();
  if(!name||!phone){alert("Please enter your name and phone number.");return;}
  const req={id:Date.now(),item,name,phone,type:isService?"service":"purchase",message:form.message?.value||"",time:new Date().toLocaleString()};
  const inbox=JSON.parse(localStorage.getItem("chiakaInbox")||"[]"); inbox.unshift(req); localStorage.setItem("chiakaInbox",JSON.stringify(inbox));
  document.getElementById("success").innerHTML=`<div class="notice"><b>Request received.</b><br>Thank you ${name}. CHIAKA AGRO will contact you on ${phone} about <b>${item}</b>.</div>`;
  form.reset();
}
function searchSite(){
  const q=(document.getElementById("q").value||"").toLowerCase().trim();
  const out=document.getElementById("results");
  if(q==="chinyammorris123"){location.href="admin.html";return;}
  if(!q){out.innerHTML="<div class='notice'>Type a product, crop or service name.</div>";return;}
  const scored=allItems().map(x=>({...x,score:(x.name+" "+x.desc).toLowerCase().includes(q)?0:1})).sort((a,b)=>a.score-b.score);
  const hits=scored.filter(x=>x.score===0);
  out.innerHTML=hits.length?hits.map(x=>`<div class="result"><div><b>${x.name}</b><br><small>${x.desc}</small></div><a class="btn blue" href="${x.type==="services"?"detail.html":"detail.html"}?id=${encodeURIComponent(x.id)}&type=${x.type}">Open</a></div>`).join(""):"<div class='notice'>No exact match found. Try a broader word such as maize, rice, herbicide, pest or farm.</div>";
}
function loadInbox(){
  const box=document.getElementById("inbox"), data=JSON.parse(localStorage.getItem("chiakaInbox")||"[]");
  box.innerHTML=data.length?data.map(r=>`<div class="inbox-item"><b>${r.type==="service"?"SERVICE REQUEST":"PURCHASE REQUEST"}</b><br><b>Item:</b> ${r.item}<br><b>Name:</b> ${r.name}<br><b>Phone:</b> ${r.phone}<br>${r.message?`<b>Message:</b> ${r.message}<br>`:""}<small>${r.time}</small></div>`).join(""):"<p>No requests yet.</p>";
}
function clearInbox(){if(confirm("Clear all requests?")){localStorage.removeItem("chiakaInbox");loadInbox();}}
function saveSettings(){
  const s={siteName:document.getElementById("siteName").value,ownerCode:document.getElementById("ownerCode").value};
  localStorage.setItem("chiakaSettings",JSON.stringify(s));alert("Settings saved on this browser.");
}
function loadSettings(){
  const s=JSON.parse(localStorage.getItem("chiakaSettings")||"{}");
  if(s.siteName)document.getElementById("siteName").value=s.siteName;
  if(s.ownerCode)document.getElementById("ownerCode").value=s.ownerCode;
}
